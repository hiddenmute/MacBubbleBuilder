#!/bin/bash

# Always run from the MacBubbleBuilder directory.
cd "$(dirname "$0")" || exit 1

ROM_PATH="ux0:/data/DaedalusX64/Roms"
MKSFOEX="./bin/vita-mksfoex"
PACKVPK="./bin/vita-pack-vpk"
IMAGE_CONVERTER="./bin/image-converter"

echo
echo "========================================"
echo " DaedalusX64 Bubble Builder"
echo "========================================"
echo

read -p "Insert bubble name: " title
read -p "Insert ROM name: " rom
read -p "Insert bubble title ID (9 characters, uppercase letters/numbers): " id

# Validate title ID

if [[ ! "$id" =~ ^[A-Z0-9]{9}$ ]]; then
    echo
    echo "ERROR: Title ID must be exactly 9 uppercase letters/numbers."
    exit 1
fi

# Check required files and directories

if [ ! -f "eboot.bin" ]; then
    echo
    echo "ERROR: eboot.bin not found."
    exit 1
fi

if [ ! -d "assets" ]; then
    echo
    echo "ERROR: assets directory not found."
    exit 1
fi

if [ ! -f "assets/startup.png" ]; then
    echo
    echo "ERROR: assets/startup.png not found."
    exit 1
fi

if [ ! -f "assets/template.xml" ]; then
    echo
    echo "ERROR: assets/template.xml not found."
    exit 1
fi

if [ ! -x "$MKSFOEX" ]; then
    echo
    echo "ERROR: vita-mksfoex not found or not executable."
    echo "Expected: $MKSFOEX"
    exit 1
fi

if [ ! -x "$PACKVPK" ]; then
    echo
    echo "ERROR: vita-pack-vpk not found or not executable."
    echo "Expected: $PACKVPK"
    exit 1
fi

if [ ! -x "$IMAGE_CONVERTER" ]; then
    echo
    echo "ERROR: image-converter not found or not executable."
    echo "Expected: $IMAGE_CONVERTER"
    exit 1
fi

# Check the game directory

GAME_DIR="games/$title"

if [ ! -d "$GAME_DIR" ]; then
    echo
    echo "ERROR: Game directory not found:"
    echo "$GAME_DIR"
    echo
    echo "Create this directory and place raw_icon0.png and raw_bg.png inside it."
    exit 1
fi

if [ ! -f "$GAME_DIR/raw_icon0.png" ]; then
    echo
    echo "ERROR: raw_icon0.png not found in $GAME_DIR/"
    exit 1
fi

if [ ! -f "$GAME_DIR/raw_bg.png" ]; then
    echo
    echo "ERROR: raw_bg.png not found in $GAME_DIR/"
    exit 1
fi

# Construct the complete ROM path

full_rom_path="$ROM_PATH/$rom"

echo
echo "ROM path:"
echo "$full_rom_path"

# Write ROM path to args.txt.
# printf is deliberately used so that no newline is added.

printf "%s" "$full_rom_path" > assets/args.txt

# Generate LiveArea images

echo
echo "Generating LiveArea images..."

"$IMAGE_CONVERTER" \
    "$GAME_DIR/raw_icon0.png" \
    "$GAME_DIR/icon0.png" \
    128 \
    128

if [ $? -ne 0 ]; then
    echo
    echo "ERROR: Icon image conversion failed."
    exit 1
fi

"$IMAGE_CONVERTER" \
    "$GAME_DIR/raw_bg.png" \
    "$GAME_DIR/bg.png" \
    840 \
    500

if [ $? -ne 0 ]; then
    echo
    echo "ERROR: Background image conversion failed."
    exit 1
fi

# Generate param.sfo

echo
echo "Generating param.sfo..."

"$MKSFOEX" \
    -s "TITLE_ID=$id" \
    "$title" \
    param.sfo

if [ $? -ne 0 ]; then
    echo
    echo "ERROR: vita-mksfoex failed."
    exit 1
fi

# Build VPK

echo
echo "Building VPK..."

"$PACKVPK" \
    -s param.sfo \
    -b eboot.bin \
    "$title.vpk" \
    -a "$GAME_DIR/icon0.png=sce_sys/icon0.png" \
    -a "$GAME_DIR/bg.png=sce_sys/livearea/contents/bg.png" \
    -a assets/startup.png=sce_sys/livearea/contents/startup.png \
    -a assets/template.xml=sce_sys/livearea/contents/template.xml \
    -a assets/args.txt=args.txt

if [ $? -ne 0 ]; then
    echo
    echo "ERROR: vita-pack-vpk failed."
    exit 1
fi

echo
echo "========================================"
echo " VPK successfully created:"
echo " $title.vpk"
echo "========================================"
echo

